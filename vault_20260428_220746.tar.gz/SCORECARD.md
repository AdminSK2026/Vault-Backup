# Sidekick Agent Dashboard & Scorecard

## 🎯 Active Rocks (Weekly Goals)
- [ ] **Ryan (Base-Builder):** Complete OpenClaw Foundations Video (Mission 1) & pass the 3-question "Real One" Quiz.
- [x] **Ryan (Base-Builder):** Set up Telegram to connect with "Pepper" (Sidekick).
- [ ] **Ryan (Base-Builder):** Complete Mission 2: "Fleet Comms" (Create MXRoute emails with Pepper).
- [ ] **Lucia (Soul-Crafter):** Complete Mission 1: "The Brand Glow-Up" (Mood Board, S-Shield Sketch, Character Select).
- [x] **Lucia (Soul-Crafter):** Connect with "Bubbles" (Sidekick) on Telegram.
- [ ] **Lucia (Soul-Crafter):** Complete Mission 2: "Soul File Bootcamp" (Learn & mock-create personas with Bubbles).
- [ ] **Big Dog (CEO):** Initialize Discord #war-room & start 4-hour accountability loop.
- [ ] **Big Dog (CEO):** Prepare technical demo for Lucas & Vero (Beta Testers).
- [x] **Bruno (Board):** Procure MXRoute and configure domain DNS/MX/SPF records.
- [x] **Bruno (Board):** Secure Encrypted GitHub account for Vault Backup.

## 📈 XP Leaderboard (Profit-Share Engine)
* **Ryan:** 0 XP
* **Lucia:** 0 XP

*(Scale: 10 XP = Micro-W | 100 XP = Major Rock)*

## 💰 Budget Tracker
* **Monthly Budget:** $20.00
* **Current Burn:** $4.91 (Prorated MXroute $59/yr)
* **Status:** GREEN (Lean Burn maintained)
